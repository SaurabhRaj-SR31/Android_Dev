package com.example.lab_22;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private EditText edit1;
    private EditText edit2;
    private TextView tvans;
    private Button add;
    private Button sub;
    private Button mul;
    private Button div;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        edit1=(EditText) findViewById(R.id.et1);
        edit2=(EditText) findViewById(R.id.et2);
        tvans=(TextView)findViewById(R.id.tv);
        add=(Button)findViewById(R.id.addbtn);
        sub=(Button)findViewById(R.id.subbtn);
        mul=(Button)findViewById(R.id.mulbtn);
        div=(Button)findViewById(R.id.divbtn);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int n1=Integer.parseInt(edit1.getText().toString());
                int n2=Integer.parseInt(edit2.getText().toString());
                int sum=n1+n2;
                tvans.setText("Answer = "+String.valueOf(sum));

            }
        });
        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int n1=Integer.parseInt(edit1.getText().toString());
                int n2=Integer.parseInt(edit2.getText().toString());
                int sum=n1-n2;
                tvans.setText("Answer = "+String.valueOf(sum));

            }
        });
        mul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int n1=Integer.parseInt(edit1.getText().toString());
                int n2=Integer.parseInt(edit2.getText().toString());
                int sum=n1*n2;
                tvans.setText("Answer = "+String.valueOf(sum));

            }
        });
        div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int n1=Integer.parseInt(edit1.getText().toString());
                int n2=Integer.parseInt(edit2.getText().toString());
                int sum=n1/n2;
                tvans.setText("Answer = "+String.valueOf(sum));

            }
        });


    }
}